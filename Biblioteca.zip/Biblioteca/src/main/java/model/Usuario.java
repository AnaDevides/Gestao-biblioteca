/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author carli
 */
public class Usuario {
    
    private int id;
    private String funcao;
    private String username;
    private String senha;
    private String nome;
    private int codigo_aluno;

    public Usuario() {
    }

    public Usuario(int id, String funcao, String username, String senha, String nome, int codigo_aluno) {
        this.id = id;
        this.funcao = funcao;
        this.username = username;
        this.senha = senha;
        this.nome = nome;
        this.codigo_aluno = codigo_aluno;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCodigo_aluno() {
        return codigo_aluno;
    }

    public void setCodigo_aluno(int codigo_aluno) {
        this.codigo_aluno = codigo_aluno;
    }
    
    
    
    
}
