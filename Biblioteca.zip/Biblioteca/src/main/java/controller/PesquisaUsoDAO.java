/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Usuario;

/**
 *
 * @author carli
 */
public class PesquisaUsoDAO {
    private final Connection con;
    
    //enviar o comando SQL para o banco
    private PreparedStatement cmd;

    public PesquisaUsoDAO() {
       this.con = Conexao.conectar();
    }
    
    
    public List<Usuario> listar(){
        try{
            String SQL = "select * from usuarios order by id";
            cmd = con.prepareStatement(SQL);
            List<Usuario> lista = new ArrayList<>();
                ResultSet rs = cmd.executeQuery();
           while (rs.next()){
                Usuario usr = new Usuario();
                usr.setNome(rs.getString("nome"));
                usr.setUsername(rs.getString("username"));
                usr.setFuncao(rs.getString("funcao"));
                usr.setUsername(rs.getString("username"));
                usr.setCodigo_aluno(rs.getInt("codigo_aluno"));
                usr.setId(rs.getInt("id"));
                
                
                lista.add(usr);
                
                }
                return lista;   

        }catch (Exception e) {
            System.err.print("ERRO: " + e.getMessage());
            return null;
        }finally{
            Conexao.desconectar(con);
        }             
    }    
    
    public Usuario pesquisarPorId(String id){
        try{
            
            String SQL = "select * from usuarios where id = ? order by id";
            cmd = con.prepareStatement(SQL);
            cmd.setInt(1, Integer.parseInt(id));
            
            //executar a consulta
            ResultSet rs = cmd.executeQuery();
            
            if(rs.next()) {           
                Usuario usr = new Usuario();
                usr.setFuncao(rs.getString("funcao"));
                usr.setUsername(rs.getString("username"));
                usr.setSenha(rs.getString("senha"));
                usr.setNome(rs.getString("nome"));
                usr.setCodigo_aluno(rs.getInt("codigo_aluno"));
                usr.setId(rs.getInt("id"));                        
            return usr;   
            }else
            {
                return null;
            }
        }catch (Exception e) {
            System.err.print("ERRO: " + e.getMessage());
            return null;
        }finally{
            Conexao.desconectar(con);
        }               
    }
    
    
    public List<Usuario> pesquisarPorNome(String Nome){
        try{
            
            String SQL = "select * from usuarios where nome ilike ? order by id";
            cmd = con.prepareStatement(SQL);
            cmd.setString(1, "%" + Nome + "%");
            
            //executar a consulta
            List<Usuario> lista = new ArrayList<>();
            ResultSet rs = cmd.executeQuery();
            
            while (rs.next()){          
                Usuario usr = new Usuario();
                usr.setFuncao(rs.getString("funcao"));
                usr.setUsername(rs.getString("username"));
                usr.setSenha(rs.getString("senha"));
                usr.setNome(rs.getString("nome"));
                usr.setCodigo_aluno(rs.getInt("codigo_aluno"));
                usr.setId(rs.getInt("id"));                
                lista.add(usr);        
            }
            
            return lista;  
        }catch (Exception e) {
            System.err.print("ERRO: " + e.getMessage());
            return null;
        }finally{
            Conexao.desconectar(con);
        }               
    }
            
    
}
